package com.example.leavemanagementsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.leavemanagementsystem.model.LeaveRequest;
import com.example.leavemanagementsystem.repository.LeaveRepository;

@Service
public class LeaveService {
	
	@Autowired
	LeaveRepository leaveRepository;

	public LeaveRequest save(LeaveRequest leaveRequest) {
		
		return leaveRepository.save(leaveRequest);
	}

	public void cancelLeaveRequest(int empno) {
		LeaveRequest leaveRequest = leaveRepository.findById(empno).orElse(null);
        if (leaveRequest != null) {
            leaveRepository.delete(leaveRequest);
		
	}
        else {
        	System.out.println(" not found");
        }
	}

//	public LeaveRequest applyLeave(LeaveRequest leaveRequest) {
//      LeaveRequest savedLeaveRequest = leaveRepository.save(leaveRequest);
//	    return savedLeaveRequest;
//	}

	



//	public int getLeaveBalance(Long employeeId) {
//		// TODO Auto-generated method stub
//		 Leave leave = leaveRepository.findByEmployeeId(employeeId);
//	        if (leave != null) {
//	            return leave.getLeaveBalance();
//	        }
//	        return 0;
//		
//	}
}

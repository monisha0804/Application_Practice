package com.example.leavemanagementsystem.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "leave")
public class LeaveRequest {

	@Id
	private int employeeno;
	private String employeeName;
	private String leaveStartDate;
	private String leaveEndDate;
	
	
	public LeaveRequest(int employeeno, String employeeName, String leaveStartDate, String leaveEndDate) {
		super();
		this.employeeno = employeeno;
		this.employeeName = employeeName;
		this.leaveStartDate = leaveStartDate;
		this.leaveEndDate = leaveEndDate;
	}

	
	
	public int getEmployeeno() {
		return employeeno;
	}
	public void setEmployeeno(int employeeno) {
		this.employeeno = employeeno;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getLeaveStartDate() {
		return leaveStartDate;
	}
	public void setLeaveStartDate(String leaveStartDate) {
		this.leaveStartDate = leaveStartDate;
	}
	public String getLeaveEndDate() {
		return leaveEndDate;
	}
	public void setLeaveEndDate(String leaveEndDate) {
		this.leaveEndDate = leaveEndDate;
	}
	
	@Override
	public String toString() {
		return "LeaveRequest [employeeno=" + employeeno + ", employeeName=" + employeeName + ", leaveStartDate="
				+ leaveStartDate + ", leaveEndDate=" + leaveEndDate + "]";
	}
	  
	
}

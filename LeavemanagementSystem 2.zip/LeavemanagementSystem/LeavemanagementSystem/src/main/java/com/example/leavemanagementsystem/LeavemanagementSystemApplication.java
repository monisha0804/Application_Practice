package com.example.leavemanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeavemanagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(LeavemanagementSystemApplication.class, args);
	}

}
